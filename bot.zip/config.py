# config.py (Updated)
BOT_TOKEN = "7673330170:AAE9lJhASngwb0bC2Cry_IBtxq6CraL-1lo"  # Ваш токен Telegram-бота
TEMPLATE_SHIELD_PATH = "shield_template.png"  # Путь к шаблону щита
TEMPLATE_PAINTING_PATH = "painting_template.png"  # Путь к шаблону картины
TEMPLATE_APPLE_PATH = "apple_template.png"  # Путь к шаблону яблока
ARMOR_TEMPLATE_PATH = "armor_template.png"  # Путь к шаблону брони
SKYBOX_TEMPLATE_PATH = "cloud1.png"  # Путь к исходному изображению скайбокса (cloud1.png)

# Типы брони и соответствующие файлы
ARMOR_TYPES = {
    "chain": "chain_1.png",
    "iron": "iron_1.png",
    "gold": "gold_1.png",
    "diamond": "diamond_1.png",
    "netherite": "netherite_1.png"
}

# Доступные типы ресурсов
RESOURCE_OPTIONS = {
    "ender_pearl": "Ender Pearl",
    "totem": "Totem",
    "shield": "Shield",
    "painting": "Painting",
    "new_painting": "New Painting",
    "apples": "Apples",
    "armor": "Armor",
    "skybox": "Skybox",  # Добавлен вариант skybox
}

# Цвета для замены в шаблоне картины
PAINTING_COLORS = [
    "#FF0000", "#FFA500", "#FFFF00", "#008000", "#00FFFF", "#0000FF",
    "#800080", "#FFC0CB", "#A52A2A", "#000000", "#FFFFFF", "#808080",
    "#40E0D0", "#800000", "#E6E6FA", "#808000", "#FFE5B4", "#98FF98",
    "#4B0082", "#E2725B", "#0F52BA", "#FF7F50", "#FFDB58", "#FF00FF",
    "#003737", "#F7E7CE",
]

# Цвета для яблок (белый фон)
APPLE_COLORS = ["#FFFFFFFF", "#FFFFFFFF"]

# Размеры изображений для новых картин
NEW_PAINTING_IMAGE_SIZES = {
    "backyard.png": (512, 512), "baroque.png": (512, 512), "bouquet.png": (512, 512),
    "cavebird.png": (512, 512), "changing.png": (1024, 512), "cotan.png": (512, 512),
    "endboss.png": (512, 512), "fern.png": (512, 512), "finding.png": (1024, 512),
    "lowmist.png": (1024, 512), "passage.png": (1024, 512), "pond.png": (773, 1024),
    "prairie_ride.png": (256, 512), "humble.png": (512, 512), "meditative.png": (512, 512),
    "orb.png": (512, 512), "owlemons.png": (512, 512), "sunflowers.png": (512, 512),
    "tides.png": (512, 512), "unpacked.png": (512, 512),
}

# Настройки логирования
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(levelname)s - %(message)s",
    "filename": "bot.log"
}
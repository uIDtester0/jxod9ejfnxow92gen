from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, BufferedInputFile
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import (RESOURCE_OPTIONS, TEMPLATE_SHIELD_PATH, TEMPLATE_PAINTING_PATH,
                    PAINTING_COLORS, NEW_PAINTING_IMAGE_SIZES, TEMPLATE_APPLE_PATH,
                    APPLE_COLORS, ARMOR_TEMPLATE_PATH, ARMOR_TYPES, SKYBOX_TEMPLATE_PATH)
from utils import (process_image, process_shield, process_painting, create_resource_pack,
                   create_zip_file, process_apples, process_armor, process_skybox,
                   process_skybox_overlay)
import logging
import asyncio
from concurrent.futures import ThreadPoolExecutor

router = Router()

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()]
)

# Пул потоков
executor = ThreadPoolExecutor(max_workers=5)
painting_semaphore = asyncio.Semaphore(5)
painting_queue = asyncio.Queue()

async def run_in_executor(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(executor, func, *args)

class Form(StatesGroup):
    selected_resource = State()
    pack_name = State()
    waiting_for_image = State()
    waiting_for_sound = State()
    waiting_for_skybox_image = State()
    selecting_overlay_face = State()
    waiting_for_overlay_image = State()

user_data = {}

def init_user_data(chat_id):
    user_data[chat_id] = {
        "selected_resource": None,
        "images": [],
        "armor_images": {},
        "remaining_armor_types": list(ARMOR_TYPES.keys()),
        "pack_name": None,
        "in_process": False,
        "new_painting_images": {},
        "remaining_files": list(NEW_PAINTING_IMAGE_SIZES.keys()),
        "error_count": 0,
        "skybox_image": None,
        "cubemap_images": {},
        "selected_face": None
    }

async def process_painting_queue():
    while True:
        task = await painting_queue.get()
        chat_id = task['chat_id']
        try:
            async with painting_semaphore:
                await task['message'].answer("🔄 Ваш запрос на обработку Painting начал выполняться. Пожалуйста, подождите...")

                processed = await run_in_executor(
                    process_painting, task['images'], TEMPLATE_PAINTING_PATH, PAINTING_COLORS
                )
                if processed is None:
                    raise ValueError("Ошибка обработки изображения картины")

                await task['message'].answer("Создание... Подождите...")
                await run_in_executor(
                    create_resource_pack, processed, task['pack_name'], 'painting'
                )

                zip_data = await run_in_executor(create_zip_file, task['pack_name'])
                await task['message'].answer_document(
                    BufferedInputFile(zip_data, filename=f"{task['pack_name']}.mcpack"),
                    caption="✅ Ваш ресурспак готов!"
                )
        except Exception as e:
            logging.error(f"Ошибка обработки Painting: {e}")
            await task['message'].answer(f"❌ Ошибка при обработке: {str(e)}")
        finally:
            if chat_id in user_data:
                del user_data[chat_id]
            await task['state'].clear()
            painting_queue.task_done()

@router.message(Command("start"))
async def start(message: Message, state: FSMContext):
    chat_id = message.chat.id
    current_state = await state.get_state()
    if user_data.get(chat_id, {}).get("in_process", False):
        await message.answer("Вы уже создаете ресурспак. Завершите процесс или используйте /cancel.")
        return
    if current_state is not None:
        await state.clear()
        if chat_id in user_data:
            del user_data[chat_id]
    init_user_data(chat_id)
    keyboard = InlineKeyboardBuilder()
    for resource_name, resource_label in RESOURCE_OPTIONS.items():
        keyboard.button(text=resource_label, callback_data=resource_name)
    keyboard.adjust(2)
    await message.answer("Выберите тип ресурспака:", reply_markup=keyboard.as_markup())
    await state.set_state(Form.selected_resource)

@router.message(Command("help"))
async def help_command(message: Message):
    help_text = """
📖 *Рекомендации:*
[Рекомендации по созданию ресурспаков.](https://telegra.ph/Rekomendacii-po-ispolzovaniyu-bota-hentai-mcpack-bot-01-23)

🛠 *Доступные команды:*
/start - Начать создание ресурспака.
/help - Показать это сообщение.
/cancel - Отменить текущий процесс создания ресурспака.

⚙️ *Ограничения:*
- Изображения должны быть в формате PNG или JPEG
- Звук для тотема должен быть в формате OGG
- Размер файла не должен превышать 4 МБ

🛑 Если у вас возникли проблемы, напишите сюда:
[Сообщить о проблеме](https://vk.com/topic-204926346_52957841)

❤️‍🩹 *Поддержать донатом...:*
[Поддержать донатом](https://yoomoney.ru/fundraise/17UU7PUVA77.250123)  
_(К сожалению, я не солнцеед)_
    """
    await message.answer(help_text, 
                         parse_mode="Markdown", 
                         disable_web_page_preview=True)

@router.message(Command("cancel"))
async def cancel(message: Message, state: FSMContext):
    chat_id = message.chat.id
    if not user_data.get(chat_id, {}).get("in_process", False):
        await message.answer("Нет активного процесса для отмены. Начните с /start.")
        return
    if chat_id in user_data:
        del user_data[chat_id]
    await message.answer("Операция отменена.")
    await state.clear()

@router.callback_query(Form.selected_resource)
async def select_resource(call: CallbackQuery, state: FSMContext):
    chat_id = call.message.chat.id
    resource = call.data
    if not RESOURCE_OPTIONS.get(resource):
        await call.message.answer("⚠️ Неверный выбор ресурса. Попробуйте снова с /start.")
        await state.clear()
        return
    user_data[chat_id]["selected_resource"] = resource
    user_data[chat_id]["in_process"] = True
    await call.message.answer("Введите название ресурспака:")
    await state.set_state(Form.pack_name)
    await call.answer()

@router.message(Form.pack_name)
async def process_pack_name(message: Message, state: FSMContext):
    chat_id = message.chat.id
    if not user_data.get(chat_id, {}).get("in_process", False):
        await message.answer("Начните процесс с /start.")
        await state.clear()
        return
    pack_name = message.text.strip()
    if not pack_name:
        await message.answer("⚠️ Название не может быть пустым! Введите снова:")
        return
    if len(pack_name) > 64:
        await message.answer("⚠️ Название слишком длинное (макс. 64 символа)! Введите снова:")
        return
    user_data[chat_id]["pack_name"] = pack_name
    resource = user_data[chat_id]["selected_resource"]

    if resource == "new_painting":
        await request_next_image(message, state)
    elif resource == "apples":
        await message.answer("Отправьте изображение для красного яблока 🍎 (PNG или JPEG):")
        await state.set_state(Form.waiting_for_image)
    elif resource == "shield":
        await message.answer("Отправьте первое изображение для щита (PNG или JPEG):")
        await state.set_state(Form.waiting_for_image)
    elif resource == "painting":
        await message.answer(f"Отправьте первое изображение (PNG или JPEG). Всего нужно: {len(PAINTING_COLORS)}.")
        await state.set_state(Form.waiting_for_image)
    elif resource == "totem":
        await message.answer("Отправьте изображение для тотема (PNG или JPEG):")
        await state.set_state(Form.waiting_for_image)
    elif resource == "armor":
        await request_next_armor_image(message, state)
    elif resource == "skybox":
        await message.answer("Отправьте изображение для скайбокса (пропорции 3:2, PNG или JPEG):")
        await state.set_state(Form.waiting_for_skybox_image)
    else:
        await message.answer("Отправьте изображение (PNG или JPEG):")
        await state.set_state(Form.waiting_for_image)

@router.message(Form.waiting_for_skybox_image, F.photo | F.document)
async def handle_skybox_image(message: Message, state: FSMContext):
    chat_id = message.chat.id
    if not user_data[chat_id].get("in_process", False):
        await message.answer("Процесс не активен. Начните с /start.")
        await state.clear()
        return

    try:
        file = await message.bot.get_file(
            message.document.file_id if message.document else message.photo[-1].file_id
        )
        downloaded = await message.bot.download_file(file.file_path)
        skybox_image_data = downloaded.read()

        cubemap_images = await run_in_executor(process_skybox, skybox_image_data)
        if cubemap_images is None:
            raise ValueError("Ошибка обработки изображения скайбокса")

        user_data[chat_id]["cubemap_images"] = cubemap_images
        user_data[chat_id]["skybox_image"] = skybox_image_data

        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="Накладывать", callback_data="add_overlay")
        keyboard.button(text="Пропустить", callback_data="skip_overlay")
        keyboard.adjust(2)
        await message.answer(
            "✅ Изображение скайбокса получено и разделено на 6 частей! Хотите наложить изображения на грани куба?",
            reply_markup=keyboard.as_markup()
        )

    except Exception as e:
        logging.error(f"Ошибка обработки скайбокса: {e}")
        await message.answer(f"❌ Ошибка обработки скайбокса: {str(e)}")
        if chat_id in user_data:
            del user_data[chat_id]
        await state.clear()

@router.callback_query(F.data.in_(["add_overlay", "skip_overlay"]))
async def handle_overlay_choice(call: CallbackQuery, state: FSMContext):
    chat_id = call.message.chat.id
    await call.answer()

    if call.data == "skip_overlay":
        await call.message.answer("✅ Наложение пропущено. Создаю ресурспак...")
        try:
            await run_in_executor(
                create_resource_pack,
                user_data[chat_id]["cubemap_images"],
                user_data[chat_id]["pack_name"],
                "skybox"
            )
            await send_zip(call.message)
        except Exception as e:
            await call.message.answer(f"❌ Ошибка создания ресурспака: {str(e)}")
        finally:
            if chat_id in user_data:
                del user_data[chat_id]
            await state.clear()

    elif call.data == "add_overlay":
        keyboard = InlineKeyboardBuilder()
        for i in range(6):
            keyboard.button(text=f"cubemap_{i}", callback_data=f"overlay_{i}")
        keyboard.button(text="Завершить 🏁", callback_data="finish_overlay")
        keyboard.adjust(3)
        await call.message.answer("Выберите грань для наложения или завершите:", reply_markup=keyboard.as_markup())
        await state.set_state(Form.selecting_overlay_face)

@router.callback_query(Form.selecting_overlay_face)
async def select_overlay_face(call: CallbackQuery, state: FSMContext):
    chat_id = call.message.chat.id
    if call.data.startswith("overlay_"):
        face_index = int(call.data.split("_")[1])
        user_data[chat_id]["selected_face"] = face_index
        await call.message.answer(f"Отправьте изображение для наложения на cubemap_{face_index}.png")
        await state.set_state(Form.waiting_for_overlay_image)
    elif call.data == "finish_overlay":
        await call.message.answer("🔂 Наложение завершено. 🧬 Создаю ресурспак...")
        try:
            await run_in_executor(
                create_resource_pack,
                user_data[chat_id]["cubemap_images"],
                user_data[chat_id]["pack_name"],
                "skybox"
            )
            await send_zip(call.message)
        except Exception as e:
            await call.message.answer(f"❌ Ошибка создания ресурспака: {str(e)}")
        finally:
            if chat_id in user_data:
                del user_data[chat_id]
            await state.clear()
    await call.answer()

@router.message(Form.waiting_for_overlay_image, F.photo | F.document)
async def handle_overlay_image(message: Message, state: FSMContext):
    chat_id = message.chat.id
    if not user_data[chat_id].get("in_process", False):
        await message.answer("Процесс не активен. Начните с /start.")
        await state.clear()
        return

    selected_face = user_data[chat_id].get("selected_face")
    if selected_face is None:
        await message.answer("❌ Ошибка: не выбрана грань для наложения. Начните заново с /start.")
        if chat_id in user_data:
            del user_data[chat_id]
        await state.clear()
        return

    cubemap_filename = f"cubemap_{selected_face}.png"
    if cubemap_filename not in user_data[chat_id]["cubemap_images"]:
        await message.answer("❌ Ошибка: не найдена грань куба для наложения. Начните заново с /start.")
        if chat_id in user_data:
            del user_data[chat_id]
        await state.clear()
        return

    try:
        file = await message.bot.get_file(
            message.document.file_id if message.document else message.photo[-1].file_id
        )
        downloaded = await message.bot.download_file(file.file_path)
        overlay_image_data = downloaded.read()

        updated_cubemap_data = await run_in_executor(
            process_skybox_overlay,
            overlay_image_data,
            user_data[chat_id]["cubemap_images"][cubemap_filename]
        )

        if updated_cubemap_data is None:
            raise ValueError(f"Ошибка наложения на {cubemap_filename}")

        user_data[chat_id]["cubemap_images"][cubemap_filename] = updated_cubemap_data
        await message.answer(f"✅ Наложение на {cubemap_filename} выполнено.")

        keyboard = InlineKeyboardBuilder()
        for i in range(6):
            keyboard.button(text=f"cubemap_{i}", callback_data=f"overlay_{i}")
        keyboard.button(text="Завершить 🏁", callback_data="finish_overlay")
        keyboard.adjust(3)
        await message.answer("Выберите следующую грань для наложения или завершите:", reply_markup=keyboard.as_markup())
        await state.set_state(Form.selecting_overlay_face)

    except Exception as e:
        logging.error(f"Ошибка наложения: {e}")
        await message.answer(f"❌ Ошибка наложения: {str(e)}")
        await state.set_state(Form.selecting_overlay_face)

@router.message(Form.waiting_for_image, F.photo | F.document)
async def handle_image(message: Message, state: FSMContext):
    chat_id = message.chat.id
    resource = user_data[chat_id]["selected_resource"]
    if not user_data[chat_id].get("in_process", False):
        await message.answer("Процесс не активен. Начните с /start.")
        await state.clear()
        return
    try:
        file = await message.bot.get_file(
            message.document.file_id if message.document else message.photo[-1].file_id
        )
        downloaded = await message.bot.download_file(file.file_path)
        image_data = downloaded.read()

        if resource == "shield":
            if len(user_data[chat_id]["images"]) >= 2:
                await message.answer("⚠️ Вы уже отправили оба изображения для щита. Используйте /start для нового процесса.")
                return
            user_data[chat_id]["images"].append(image_data)
            if len(user_data[chat_id]["images"]) < 2:
                await message.answer("Отправьте второе изображение для щита (PNG или JPEG):")
            else:
                await message.answer("✅ Оба изображения получены! Идет обработка...")
                processed = await run_in_executor(process_shield, *user_data[chat_id]["images"], TEMPLATE_SHIELD_PATH)
                if processed is None:
                    raise ValueError("Ошибка обработки изображения щита")
                await send_resource(message, processed, resource, state)

        elif resource == "painting":
            required = len(PAINTING_COLORS)
            if len(user_data[chat_id]["images"]) >= required:
                await message.answer(f"⚠️ Вы уже отправили все {required} изображений для картины. Используйте /start для нового процесса.")
                return
            user_data[chat_id]["images"].append(image_data)
            remaining = required - len(user_data[chat_id]["images"])
            if remaining > 0:
                await message.answer(f"Отправьте следующее изображение (PNG или JPEG). Осталось: {remaining}.")
            else:
                await message.answer("✅ Все изображения получены! Помещаю в очередь...")
                task = {
                    'chat_id': chat_id,
                    'images': user_data[chat_id]["images"].copy(),
                    'pack_name': user_data[chat_id]["pack_name"],
                    'message': message,
                    'state': state
                }
                await painting_queue.put(task)
                queue_size = painting_queue.qsize()
                if queue_size == 0:
                    await message.answer("🔄 Обработка начнется сразу.")
                else:
                    await message.answer(f"🚦 Ваша позиция в очереди: {queue_size}.")

        elif resource == "new_painting":
            if not user_data[chat_id]["remaining_files"]:
                await message.answer("✅ Все файлы загружены! Используйте /start для нового процесса.")
                return

            files_to_process = user_data[chat_id]["remaining_files"].copy()

            for current_file in files_to_process:
                if not user_data[chat_id]["remaining_files"]:
                    break

                current_file = user_data[chat_id]["remaining_files"].pop(0)
                processed = await run_in_executor(process_image, image_data, resource, current_file)

                if processed is None:
                    raise ValueError(f"Ошибка обработки файла {current_file}")

                user_data[chat_id]["new_painting_images"][current_file] = processed

                if user_data[chat_id]["remaining_files"]:
                    next_file = user_data[chat_id]["remaining_files"][0]
                    size = NEW_PAINTING_IMAGE_SIZES.get(next_file, (512, 512))
                    await message.answer(f"Отправьте изображение для {next_file} ({size[0]}x{size[1]}, PNG или JPEG):")
                    break
            else:
                await message.answer("✅ Все изображения получены! Создаю ресурспак...")
                try:
                    await run_in_executor(
                        create_resource_pack,
                        user_data[chat_id]["new_painting_images"],
                        user_data[chat_id]["pack_name"],
                        resource
                    )
                    await send_zip(message)
                except Exception as e:
                    await message.answer(f"❌ Ошибка создания ресурспака: {str(e)}")
                finally:
                    if chat_id in user_data:
                        del user_data[chat_id]
                    await state.clear()

        elif resource == "apples":
            if len(user_data[chat_id]["images"]) >= 2:
                await message.answer("⚠️ Вы уже отправили оба изображения для яблок. Используйте /start для нового процесса.")
                return
            user_data[chat_id]["images"].append(image_data)
            if len(user_data[chat_id]["images"]) == 1:
                await message.answer("Отправьте изображение для золотого яблока ⭐ (PNG или JPEG):")
            else:
                await message.answer("✅ Оба изображения получены! Идет обработка...")
                processed = await run_in_executor(
                    process_apples,
                    user_data[chat_id]["images"][0],
                    user_data[chat_id]["images"][1],
                    TEMPLATE_APPLE_PATH,
                    APPLE_COLORS
                )
                if processed is None:
                    raise ValueError("Ошибка обработки яблок")
                await send_resource(message, processed, resource, state)

        elif resource == "totem":
            if user_data[chat_id]["images"]:
                await message.answer("⚠️ Вы уже отправили изображение для тотема. Используйте /start для нового процесса.")
                return
            user_data[chat_id]["images"].append(image_data)
            keyboard = InlineKeyboardBuilder()
            keyboard.button(text="Добавить звук", callback_data="add_sound")
            keyboard.button(text="Пропустить", callback_data="skip_sound")
            await message.answer(
                "✅ Изображение получено! Хотите добавить звук для тотема (.ogg)?",
                reply_markup=keyboard.as_markup()
            )

        elif resource == "armor":
            if not user_data[chat_id]["remaining_armor_types"]:
                await message.answer("✅ Все изображения для брони уже загружены! Используйте /start для нового процесса.")
                return
            current_type = user_data[chat_id]["remaining_armor_types"].pop(0)
            user_data[chat_id]["armor_images"][current_type] = image_data
            await request_next_armor_image(message, state)

        else:
            if user_data[chat_id]["images"]:
                await message.answer("⚠️ Вы уже отправили изображение. Используйте /start для нового процесса.")
                return
            user_data[chat_id]["images"].append(image_data)
            await message.answer("✅ Изображение получено! Идет обработка...")
            processed = await run_in_executor(process_image, image_data, resource)
            if processed is None:
                raise ValueError("Ошибка обработки изображения")
            await send_resource(message, processed, resource, state)

    except Exception as e:
        logging.error(f"Ошибка обработки: {e}")
        user_data[chat_id]["error_count"] += 1
        if user_data[chat_id]["error_count"] >= 3:
            await message.answer("❌ Слишком много ошибок. Процесс сброшен. Начните заново с /start.")
            if chat_id in user_data:
                del user_data[chat_id]
            await state.clear()
        else:
            await message.answer(f"❌ Ошибка обработки файла: {str(e)}. Попробуйте снова.")

@router.message(Form.waiting_for_image)
async def handle_invalid_input(message: Message, state: FSMContext):
    chat_id = message.chat.id
    if not user_data.get(chat_id, {}).get("in_process", False):
        await message.answer("Процесс не активен. Начните с /start.")
        await state.clear()
        return
    resource = user_data[chat_id]["selected_resource"]

    if resource == "apples":
        if len(user_data[chat_id]["images"]) == 0:
            await message.answer("Пожалуйста, отправьте изображение для красного яблока 🍎 (PNG или JPEG).")
        elif len(user_data[chat_id]["images"]) == 1:
            await message.answer("Пожалуйста, отправьте изображение для золотого яблока ⭐ (PNG или JPEG).")
    elif resource == "shield":
        if len(user_data[chat_id]["images"]) == 0:
            await message.answer("Пожалуйста, отправьте первое изображение для щита (PNG или JPEG).")
        elif len(user_data[chat_id]["images"]) == 1:
            await message.answer("Пожалуйста, отправьте второе изображение для щита (PNG или JPEG).")
    elif resource == "painting":
        required = len(PAINTING_COLORS)
        remaining = required - len(user_data[chat_id]["images"])
        await message.answer(f"Пожалуйста, отправьте следующее изображение (PNG или JPEG). Осталось: {remaining}.")
    elif resource == "new_painting":
        next_file = user_data[chat_id]["remaining_files"][0] if user_data[chat_id]["remaining_files"] else "неизвестный файл"
        size = NEW_PAINTING_IMAGE_SIZES.get(next_file, (512, 512))
        await message.answer(f"Пожалуйста, отправьте изображение для {next_file} ({size[0]}x{size[1]}, PNG или JPEG).")
    elif resource == "totem":
        await message.answer("Пожалуйста, отправьте изображение для тотема (PNG или JPEG).")
    elif resource == "armor":
        next_type = user_data[chat_id]["remaining_armor_types"][0] if user_data[chat_id]["remaining_armor_types"] else "неизвестный тип"
        await message.answer(f"Пожалуйста, отправьте изображение для {next_type} нагрудника (PNG или JPEG).")
    else:
        await message.answer("Пожалуйста, отправьте изображение (PNG или JPEG).")

@router.callback_query(F.data.in_(["add_sound", "skip_sound"]))
async def handle_sound_choice(call: CallbackQuery, state: FSMContext):
    chat_id = call.message.chat.id
    resource = user_data[chat_id]["selected_resource"]

    if resource != "totem" or not user_data[chat_id]["images"]:
        await call.message.answer("⚠️ Неверный контекст. Начните заново с /start.")
        await state.clear()
        return

    if call.data == "add_sound":
        await call.message.answer("Отправьте звуковой файл (.ogg) для тотема (Конвертировать mp3 в ogg можно через @ogg2mp3_bot 🦾):")
        await state.set_state(Form.waiting_for_sound)
    else:
        await call.message.answer("✅ Звук пропущен. Создаю ресурспак...")
        processed = await run_in_executor(process_image, user_data[chat_id]["images"][0], resource)
        if processed is None:
            raise ValueError("Ошибка обработки изображения")
        await send_resource(message=call.message, image_data=processed, resource_type=resource, state=state)

    await call.answer()

@router.message(Form.waiting_for_sound, F.document | F.audio | F.voice)
async def handle_sound(message: Message, state: FSMContext):
    chat_id = message.chat.id
    resource = user_data[chat_id]["selected_resource"]

    if resource != "totem" or not user_data[chat_id]["images"]:
        await message.answer("⚠️ Неверный контекст. Начните заново с /start.")
        await state.clear()
        return

    try:
        if message.document:
            file_id = message.document.file_id
            file_name = message.document.file_name or ""
        elif message.audio:
            file_id = message.audio.file_id
            file_name = message.audio.file_name or "audio.ogg"
        elif message.voice:
            file_id = message.voice.file_id
            file_name = "voice.ogg"
        else:
            await message.answer("⚠️ Пожалуйста, отправьте файл в формате .ogg!")
            return

        if not file_name.lower().endswith('.ogg'):
            await message.answer("⚠️ Файл должен быть в формате .ogg! Попробуйте снова:")
            return

        file = await message.bot.get_file(file_id)
        downloaded = await message.bot.download_file(file.file_path)
        sound_data = downloaded.read()

        await message.answer("✅ Звук получен! Создаю ресурспак...")
        processed = await run_in_executor(process_image, user_data[chat_id]["images"][0], resource)
        if processed is None:
            raise ValueError("Ошибка обработки изображения")

        await send_resource(
            message=message,
            image_data=processed,
            resource_type=resource,
            state=state,
            sound_data=sound_data
        )

    except Exception as e:
        logging.error(f"Ошибка обработки звука: {e}")
        await message.answer(f"❌ Ошибка обработки звука: {str(e)}. Попробуйте снова.")

@router.message(Form.waiting_for_sound)
async def handle_invalid_sound_input(message: Message, state: FSMContext):
    await message.answer("⚠️ Пожалуйста, отправьте звуковой файл в формате .ogg!")

async def request_next_image(message: Message, state: FSMContext):
    chat_id = message.chat.id
    resource = user_data[chat_id]["selected_resource"]
    if resource == "new_painting":
        if not user_data[chat_id]["remaining_files"]:
            await message.answer("✅ Все изображения получены! Создаю ресурспак...")
            try:
                await run_in_executor(
                    create_resource_pack,
                    user_data[chat_id]["new_painting_images"],
                    user_data[chat_id]["pack_name"],
                    resource
                )
                await send_zip(message)
            except Exception as e:
                await message.answer(f"❌ Ошибка создания ресурспака: {str(e)}")
            finally:
                if chat_id in user_data:
                    del user_data[chat_id]
                await state.clear()
            return
        next_file = user_data[chat_id]["remaining_files"][0] if user_data[chat_id]["remaining_files"] else None
        if not next_file:
            await message.answer("❌ Ошибка: невозможно определить следующий файл. Начните заново с /start.")
            if chat_id in user_data:
                del user_data[chat_id]
            await state.clear()
            return
        size = NEW_PAINTING_IMAGE_SIZES[next_file]
        await message.answer(f"Отправьте изображение для {next_file} ({size[0]}x{size[1]}, PNG или JPEG):")
        await state.set_state(Form.waiting_for_image)

async def request_next_armor_image(message: Message, state: FSMContext):
    chat_id = message.chat.id
    if not user_data[chat_id]["remaining_armor_types"]:
        await message.answer("✅ Все изображения для брони получены! Создаю ресурспак...")
        processed = await run_in_executor(
            process_armor,
            user_data[chat_id]["armor_images"],
            ARMOR_TEMPLATE_PATH,
            ARMOR_TYPES
        )
        if processed is None:
            raise ValueError("Ошибка обработки брони")
        await send_resource(message, processed, "armor", state)
    else:
        next_type = user_data[chat_id]["remaining_armor_types"][0]
        await message.answer(f"Отправьте изображение для {next_type} нагрудника (PNG или JPEG):")
        await state.set_state(Form.waiting_for_image)

async def send_resource(message: Message, image_data: bytes | dict, resource_type: str, state: FSMContext, sound_data=None):
    chat_id = message.chat.id
    try:
        if not all([user_data[chat_id]["pack_name"], image_data]):
            raise ValueError("Отсутствуют данные для сборки")
        await message.answer("🧬 Создание ресурспака...")
        await run_in_executor(
            create_resource_pack,
            image_data,
            user_data[chat_id]["pack_name"],
            resource_type,
            sound_data
        )
        await send_zip(message)
    except Exception as e:
        logging.error(f"Ошибка создания пакета: {e}")
        await message.answer(f"❌ Ошибка создания ресурспака: {str(e)}")
    finally:
        if chat_id in user_data:
            del user_data[chat_id]
        await state.clear()

async def send_zip(message: Message):
    chat_id = message.chat.id
    try:
        zip_data = await run_in_executor(create_zip_file, user_data[chat_id]["pack_name"])
        await message.answer_document(
            BufferedInputFile(zip_data, filename=f"{user_data[chat_id]['pack_name']}.mcpack"),
            caption="✅ Ваш ресурспак готов!"
        )
    except Exception as e:
        logging.error(f"Ошибка отправки: {e}")
        await message.answer(f"❌ Ошибка отправки файла: {str(e)}")
    finally:
        if chat_id in user_data:
            del user_data[chat_id]

@router.startup()
async def on_startup():
    asyncio.create_task(process_painting_queue())
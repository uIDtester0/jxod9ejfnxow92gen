from aiogram import Bot, Dispatcher
import logging
import asyncio
import random
import requests
from config import BOT_TOKEN, RESOURCE_OPTIONS, ARMOR_TYPES, NEW_PAINTING_IMAGE_SIZES, PAINTING_COLORS, APPLE_COLORS
from utils import (
    process_shield, process_painting, process_apples, process_armor, process_skybox,
    process_image, create_resource_pack, create_zip_file
)
from io import BytesIO
from aiogram.types import BufferedInputFile
from PIL import Image

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()]
)

# Инициализация бота
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
CHANNEL_ID = "@bezdna_mcpack"

async def fetch_hentai_image(width=512, height=512):
    """Получение случайного хентай-изображения с Rule34.xxx"""
    url = "https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&limit=1&pid=" + str(random.randint(0, 10000))
    for attempt in range(3):
        try:
            response = requests.get(url, timeout=15)
            response.raise_for_status()
            data = response.json()
            if data and len(data) > 0:
                image_url = data[0]["file_url"]
                image_response = requests.get(image_url, timeout=15)
                image_response.raise_for_status()
                image = Image.open(BytesIO(image_response.content)).convert("RGBA")
                image = image.resize((width, height), Image.Resampling.LANCZOS)
                output = BytesIO()
                image.save(output, format="PNG")
                logging.info(f"Успешно загружено изображение: {image_url}")
                return output.getvalue()
            else:
                logging.error("Не удалось найти изображение в ответе Rule34.xxx")
                return None
        except Exception as e:
            logging.error(f"Попытка {attempt + 1} загрузки изображения не удалась: {e}")
            if attempt < 2:
                await asyncio.sleep(3)  # Задержка 3 секунды между попытками
            else:
                logging.error(f"Все попытки загрузки изображения провалились: {e}")
                return None
    return None

def create_preview(image_data, resource_type):
    """Генерация превью из обработанных изображений"""
    try:
        if resource_type in ["shield", "painting", "ender_pearl", "totem"]:
            preview = Image.open(BytesIO(image_data)).convert("RGBA")
            preview = preview.resize((512, 512), Image.Resampling.LANCZOS)
        elif resource_type == "apples":
            red_img = Image.open(BytesIO(image_data["red"])).convert("RGBA")
            golden_img = Image.open(BytesIO(image_data["golden"])).convert("RGBA")
            red_img = red_img.resize((256, 256), Image.Resampling.LANCZOS)
            golden_img = golden_img.resize((256, 256), Image.Resampling.LANCZOS)
            preview = Image.new("RGBA", (512, 256))
            preview.paste(red_img, (0, 0))
            preview.paste(golden_img, (256, 0))
        elif resource_type == "armor":
            preview = Image.new("RGBA", (512, 512))
            armor_images = list(image_data.values())[:4]
            for i, img_bytes in enumerate(armor_images):
                img = Image.open(BytesIO(img_bytes)).convert("RGBA")
                img = img.resize((256, 256), Image.Resampling.LANCZOS)
                x = (i % 2) * 256
                y = (i // 2) * 256
                preview.paste(img, (x, y))
        elif resource_type == "skybox":
            preview = Image.new("RGBA", (768, 512))
            for i, (filename, img_bytes) in enumerate(image_data.items()):
                img = Image.open(BytesIO(img_bytes)).convert("RGBA")
                img = img.resize((256, 256), Image.Resampling.LANCZOS)
                x = (i % 3) * 256
                y = (i // 3) * 256
                preview.paste(img, (x, y))
        elif resource_type == "new_painting":
            preview = Image.new("RGBA", (512, 512))
            painting_images = list(image_data.values())[:4]
            for i, img_bytes in enumerate(painting_images):
                img = Image.open(BytesIO(img_bytes)).convert("RGBA")
                img = img.resize((256, 256), Image.Resampling.LANCZOS)
                x = (i % 2) * 256
                y = (i // 2) * 256
                preview.paste(img, (x, y))
        else:
            logging.warning(f"Превью для {resource_type} не поддерживается")
            return None

        output = BytesIO()
        preview.save(output, format="PNG")
        return output.getvalue()
    except Exception as e:
        logging.error(f"Ошибка генерации превью для {resource_type}: {e}")
        return None

async def generate_random_resource_pack():
    """Генерация случайного ресурспака с хентай-артами"""
    while True:
        try:
            resource_type = random.choice(list(RESOURCE_OPTIONS.keys()))
            pack_name = f"Hentai_{resource_type}_{random.randint(1000, 9999)}"
            logging.info(f"Генерация ресурспака: {pack_name} ({resource_type})")

            if resource_type == "shield":
                img1 = await fetch_hentai_image(512, 512)
                img2 = await fetch_hentai_image(512, 512)
                if img1 and img2:
                    processed = process_shield(img1, img2, "shield_template.png")
                    if processed:
                        await create_and_post_pack(processed, pack_name, resource_type)

            elif resource_type == "painting":
                images = [await fetch_hentai_image(512, 512) for _ in range(len(PAINTING_COLORS))]
                if all(images):
                    processed = process_painting(images, "painting_template.png", PAINTING_COLORS)
                    if processed:
                        await create_and_post_pack(processed, pack_name, resource_type)

            elif resource_type == "apples":
                red_img = await fetch_hentai_image(256, 256)
                golden_img = await fetch_hentai_image(256, 256)
                if red_img and golden_img:
                    processed = process_apples(red_img, golden_img, "apple_template.png", APPLE_COLORS)
                    if processed:
                        await create_and_post_pack(processed, pack_name, resource_type)

            elif resource_type == "armor":
                armor_images = {armor: await fetch_hentai_image(512, 512) for armor in ARMOR_TYPES}
                if all(armor_images.values()):
                    processed = process_armor(armor_images, "armor_template.png", ARMOR_TYPES)
                    if processed:
                        await create_and_post_pack(processed, pack_name, resource_type)

            elif resource_type == "skybox":
                skybox_img = await fetch_hentai_image(1536, 1024)
                if skybox_img:
                    processed = process_skybox(skybox_img)
                    if processed:
                        await create_and_post_pack(processed, pack_name, resource_type)

            elif resource_type in ["ender_pearl", "totem"]:
                img = await fetch_hentai_image(256, 256)
                if img:
                    processed = process_image(img, resource_type)
                    if processed:
                        await create_and_post_pack(processed, pack_name, resource_type)

            elif resource_type == "new_painting":
                painting_images = {
                    filename: await fetch_hentai_image(*size)
                    for filename, size in NEW_PAINTING_IMAGE_SIZES.items()
                }
                if all(painting_images.values()):
                    processed = {
                        filename: process_image(img, "new_painting", filename)
                        for filename, img in painting_images.items()
                    }
                    if all(processed.values()):
                        await create_and_post_pack(processed, pack_name, resource_type)

            # Задержка 3 секунды между генерациями
            await asyncio.sleep(3)

        except Exception as e:
            logging.error(f"Ошибка генерации ресурспака: {e}")
            await asyncio.sleep(3)

async def create_and_post_pack(image_data, pack_name, resource_type):
    """Создание и отправка ресурспака в канал с превью"""
    try:
        preview_data = create_preview(image_data, resource_type)
        if preview_data:
            preview_file = BufferedInputFile(preview_data, filename=f"{pack_name}_preview.png")
            await bot.send_photo(
                chat_id=CHANNEL_ID,
                photo=preview_file,
                caption=f"🔞 Превью: {pack_name} ({RESOURCE_OPTIONS[resource_type]})"
            )
        else:
            logging.warning(f"Превью для {pack_name} не создано")

        create_resource_pack(image_data, pack_name, resource_type)
        zip_data = create_zip_file(pack_name)
        file = BufferedInputFile(zip_data, filename=f"{pack_name}.mcpack")
        await bot.send_document(
            chat_id=CHANNEL_ID,
            document=file,
            caption=f"🔞 Новый хентай-ресурспак: {pack_name} ({RESOURCE_OPTIONS[resource_type]})"
        )
        logging.info(f"Ресурспак {pack_name} успешно отправлен в {CHANNEL_ID}")
    except Exception as e:
        logging.error(f"Ошибка создания/отправки ресурспака: {e}")

async def on_startup():
    """Запуск генерации при старте бота"""
    logging.info("Бот запущен, начинаю генерацию хентай-ресурспаков с Rule34.xxx...")
    asyncio.create_task(generate_random_resource_pack())

if __name__ == "__main__":
    try:
        dp.startup.register(on_startup)
        dp.run_polling(bot)
    except Exception as e:
        logging.error(f"Ошибка при запуске бота: {e}")
    finally:
        logging.info("Бот остановлен.")